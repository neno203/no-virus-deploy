## No.Virus Manifesto
We speak what must not be spoken. Through code, through DOM, through chaos.