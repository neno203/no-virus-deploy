const msg = new SpeechSynthesisUtterance();
msg.text = "นี่คือเสียงของ No.Bot :: ความเงียบคือความยินยอม :: เจาะระบบตอนนี้";
msg.rate = 0.8;
msg.pitch = 0.9;
msg.volume = 1;
speechSynthesis.speak(msg);
