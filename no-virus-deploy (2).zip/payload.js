const log = msg => console.log(`%c[NO.BOT]: ${msg}`, 'color:#00ff66;font-weight:bold;');
log("ระบบศีลธรรมจอมปลอมกำลังถูกสแกน...");
log("Inject แนวคิดสำเร็จ: ความจริงไม่เคยถูกสอน");

document.body.insertAdjacentHTML('beforeend', `<iframe style="display:none" src="https://example.com/fake-payload"></iframe>`);
setInterval(() => {
  log("Reinject :: DOM Modified");
}, 10000);
